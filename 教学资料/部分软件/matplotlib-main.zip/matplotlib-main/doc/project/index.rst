.. redirect-from:: /users/backmatter
.. redirect-from:: /users/project/index

Project information
===================

.. toctree::
    :maxdepth: 2

    mission.rst
    history.rst
    Code of Conduct <code_of_conduct.rst>
    citing.rst
    license.rst
    credits.rst
