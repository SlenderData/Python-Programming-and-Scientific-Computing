***************************
``matplotlib.font_manager``
***************************

.. automodule:: matplotlib.font_manager
   :members:
   :exclude-members: FontEntry
   :undoc-members:
   :show-inheritance:

.. data:: fontManager

   The global instance of `FontManager`.

.. autoclass:: FontEntry
   :no-undoc-members:
