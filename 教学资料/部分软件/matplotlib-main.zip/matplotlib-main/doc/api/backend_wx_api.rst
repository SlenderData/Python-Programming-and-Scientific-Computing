******************************************************************************
``matplotlib.backends.backend_wxagg``, ``matplotlib.backends.backend_wxcairo``
******************************************************************************

**NOTE** These :ref:`backends` are not documented here, to avoid adding a
dependency to building the docs.

.. redirect-from:: /api/backend_wxagg_api

.. module:: matplotlib.backends.backend_wx
.. module:: matplotlib.backends.backend_wxagg
.. module:: matplotlib.backends.backend_wxcairo
