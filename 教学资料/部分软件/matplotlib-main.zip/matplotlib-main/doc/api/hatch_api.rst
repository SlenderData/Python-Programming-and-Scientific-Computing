********************
``matplotlib.hatch``
********************

.. automodule:: matplotlib.hatch
   :members:
   :undoc-members:
   :show-inheritance:
