*********************
``matplotlib.typing``
*********************

.. autodata:: matplotlib.typing.RGBColorType
.. autodata:: matplotlib.typing.RGBColourType
.. autodata:: matplotlib.typing.RGBAColorType
.. autodata:: matplotlib.typing.RGBAColourType
.. autodata:: matplotlib.typing.ColorType
.. autodata:: matplotlib.typing.ColourType
.. autodata:: matplotlib.typing.LineStyleType
.. autodata:: matplotlib.typing.DrawStyleType
.. autodata:: matplotlib.typing.MarkEveryType
.. autodata:: matplotlib.typing.FillStyleType
.. autodata:: matplotlib.typing.CapStyleType
.. autodata:: matplotlib.typing.JoinStyleType
.. autodata:: matplotlib.typing.RcStyleType
.. autodata:: matplotlib.typing.HashableList
   :annotation: Nested list with Hashable values
