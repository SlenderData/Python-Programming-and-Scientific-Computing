***********************
``matplotlib.backends``
***********************

.. module:: matplotlib.backends

.. toctree::
   :maxdepth: 1

   backend_mixed_api.rst
   backend_template_api.rst
   backend_agg_api.rst
   backend_cairo_api.rst
   backend_gtk3_api.rst
   backend_gtk4_api.rst
   backend_nbagg_api.rst
   backend_pdf_api.rst
   backend_pgf_api.rst
   backend_ps_api.rst
   backend_registry_api.rst
   backend_qt_api.rst
   backend_svg_api.rst
   backend_tk_api.rst
   backend_webagg_core_api.rst
   backend_webagg_api.rst
   backend_wx_api.rst
