**********************
``matplotlib.ft2font``
**********************

.. automodule:: matplotlib.ft2font
   :members:
   :undoc-members:
   :show-inheritance:
