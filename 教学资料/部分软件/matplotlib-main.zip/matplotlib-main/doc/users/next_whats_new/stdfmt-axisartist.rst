``axisartist`` can now be used together with standard ``Formatters``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
... instead of being limited to axisartist-specific ones.
