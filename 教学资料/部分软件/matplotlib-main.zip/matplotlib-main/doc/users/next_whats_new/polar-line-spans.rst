``axhline`` and ``axhspan`` on polar axes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

... now draw circles and circular arcs (`~.Axes.axhline`) or annuli and wedges
(`~.Axes.axhspan`).
