NonUniformImage now has mouseover support
-----------------------------------------
When mousing over a `~matplotlib.image.NonUniformImage` the data values are now
displayed.
