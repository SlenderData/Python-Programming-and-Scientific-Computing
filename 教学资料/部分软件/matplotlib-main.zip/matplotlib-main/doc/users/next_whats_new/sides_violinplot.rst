Add option to plot only one half of violin plot
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Setting the parameter *side* to 'low' or 'high' allows to only plot one half of the violin plot.
