``Axes.inset_axes`` is no longer experimental
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Axes.inset_axes is considered stable for use.
