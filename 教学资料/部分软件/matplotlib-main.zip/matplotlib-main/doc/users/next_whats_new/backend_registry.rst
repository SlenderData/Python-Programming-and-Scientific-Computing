BackendRegistry
~~~~~~~~~~~~~~~

New :class:`~matplotlib.backends.registry.BackendRegistry` class is the single
source of truth for available backends. The singleton instance is
``matplotlib.backends.backend_registry``.
