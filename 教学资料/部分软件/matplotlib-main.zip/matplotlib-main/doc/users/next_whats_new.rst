.. _whats-new:

================
Next what's new?
================

.. ifconfig:: releaselevel == 'dev'

   .. toctree::
      :glob:
      :maxdepth: 1

      next_whats_new/*
