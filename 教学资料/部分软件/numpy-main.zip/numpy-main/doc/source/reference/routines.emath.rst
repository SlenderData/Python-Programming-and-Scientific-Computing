.. _routines.emath:

Mathematical functions with automatic domain
********************************************

.. currentmodule:: numpy

.. note:: :mod:`numpy.emath` is a preferred alias for ``numpy.lib.scimath``,
          available after :mod:`numpy` is imported.

.. automodule:: numpy.emath
