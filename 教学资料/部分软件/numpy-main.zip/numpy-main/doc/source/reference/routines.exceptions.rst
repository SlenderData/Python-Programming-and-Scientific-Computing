.. _routines.exceptions:
.. automodule:: numpy.exceptions
