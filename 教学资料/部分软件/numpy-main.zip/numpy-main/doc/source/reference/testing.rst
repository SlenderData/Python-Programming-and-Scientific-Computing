.. _testing-guidelines:

Testing guidelines
==================

.. include:: ../../TESTS.rst
   :start-line: 6
