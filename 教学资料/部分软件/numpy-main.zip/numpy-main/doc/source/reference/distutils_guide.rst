.. _distutils-user-guide:

``numpy.distutils`` user guide
==============================

.. warning::

   ``numpy.distutils`` is deprecated, and will be removed for
   Python >= 3.12. For more details, see :ref:`distutils-status-migration`


.. include:: ../../DISTUTILS.rst
   :start-line: 6
